 import  express  from "express";
 import { Server as WebSocketServer } from "socket.io";
 import cors from 'cors'
 import http from 'http'

 const app = express()

 const activeUsers = new Set();
 const activeUsersIdUSer = []


 const server = http.createServer(app)
 const io = new WebSocketServer(server,{
    cors: {
        origin: "*"
      }
 })



 function deleteUser(idZ){

   
    activeUsersIdUSer.forEach(function(id, index, object) {
        if(id.id === idZ){

          object.splice(index, 1);
        }
    });

    // for (let index = 0; index < activeUsersIdUSer.length; index++) {
    //     if(id == activeUsersIdUSer[index].id){


    //         break
    //     }
        
    // }
 }

 function validUser(user,idx){
    let userValud = true
    activeUsersIdUSer.forEach((datax)=>{

        if(datax.id == idx){
            if(datax.username == user){
                userValud = false
                
            }
        }
    })

    return userValud
    
 }


 io.on("connection", (socket) => {

 

  

    socket.on("conect",(username)=>{
        io.sockets.sockets.forEach((dataSock)=>{
            if(dataSock.id == socket.id){

                if(activeUsersIdUSer.find(usr => usr.id == dataSock.id) === undefined){
     
                    activeUsersIdUSer.push({username:username,id:socket.id})
                }
            }
        })

        socket.userId = username
        activeUsers.add(username)



        console.log(activeUsers)
    })


    // socket.on('getActive',()=>{
    //     io.emit("userActive",[...activeUsers])
    // })

    
    // socket.on("send_msj",(data)=>{
        

    //     socket.broadcast.emit('recive_msj',{msj:data})
    // })


    // enviar log
    socket.on("sendsetting",(datalog)=>{

    

        let usernamex = activeUsersIdUSer.find(usr => usr.id == socket.id)
        if(usernamex != undefined){
            activeUsersIdUSer.forEach((datac) =>{

                if(datac.username == usernamex.username){

                    //pendiente

                    //io.to(datac.id).emit("updateCredit",{credit:datacredit})
                }
                
            })
        }
       
    })
    // enviar respuesta
    socket.on("sendresponse",(datalog)=>{

        let usernamex = activeUsersIdUSer.find(usr => usr.id == socket.id)
        if(usernamex != undefined){
            activeUsersIdUSer.forEach((datac) =>{

                if(datac.username == usernamex.username){

                    //pendiente

                    //io.to(datac.id).emit("updateCredit",{credit:datacredit})
                }
                
            })
        }
       
    })

    // socket.on("credit",(datacredit)=>{

    //     let usernamex = activeUsersIdUSer.find(usr => usr.id == socket.id)
    //     if(usernamex != undefined){
    //         activeUsersIdUSer.forEach((datac) =>{

    //             if(datac.username == usernamex.username){

    //                 io.to(datac.id).emit("updateCredit",{credit:datacredit})
    //             }
                
    //         })
    //     }
       
    // })


    socket.on('passeventscm',(data)=>{

        let usrinit = activeUsersIdUSer.find(usr => usr.username == data.idevent)

        if(usrinit != undefined){
            io.to(usrinit.id).emit("dataresponse",{status:data.status,typestatus:data.typeEvent})
        }else{

        let usernamex = activeUsersIdUSer.find(usr => usr.id == socket.id)
        if(usernamex != undefined){
            activeUsersIdUSer.forEach((datac) =>{

                if(datac.username == usernamex.username){

                    //pendiente

                    io.to(datac.id).emit("errordata",{nameautor:datac.username })
                }
                
            })
        }
        
    }
        console.log(usrinit)
      

        // io.emit('dataNoti',{noti:data})
    })
    socket.on('setreload',()=>{
        io.emit("getReload",{status:'reload'})
    })
    socket.on("disconnect", () => {


        //console.log(socket.id,'ID')
        deleteUser(socket.id)

       
        //console.log(activeUsersIdUSer,'QUE PES')
        activeUsers.delete(socket.userId);
        //activeUsersIdUSer.delete({username:socket.userId,id:socket.id})
        console.log("desconexion",activeUsers)

        //console.log(activeUsersIdUSer)
        socket.broadcast.emit("userActive", [...activeUsers]);
      });


  });

 server.listen(8087)
 console.log("server on port",8087)
